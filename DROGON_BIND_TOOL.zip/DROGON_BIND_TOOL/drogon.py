import requests
import os
import sys
import json
import time
import urllib.parse
import base64
import hashlib
import urllib3
from datetime import datetime
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    import MajoRLogin_pb2 as mLpB
    import MajorLoginRes_pb2 as mLrPb
except ImportError:
    print("\n\033[91m [!] Error: Protobuf files (MajoRLogin_pb2.py, MajorLoginRes_pb2.py) not found in directory!\033[0m")
    sys.exit()


class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    MAGENTA = '\033[95m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    END = '\033[0m'
    GOLD = '\033[93m'
    DARK_RED = '\033[31m'
    LIGHT_BLUE = '\033[94m'
    PURPLE = '\033[95m'
    ORANGE = '\033[38;5;208m'


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def draw_header(subtitle=""):
    clear_screen()
    
    # DROGON 🐉 Premium Banner
    dragon_logo = f"""{Colors.GOLD}
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║      ██████╗ ██████╗  ██████╗  ██████╗ ███╗   ██╗      ║
║      ██╔══██╗██╔══██╗██╔═══██╗██╔═══██╗████╗  ██║      ║
║      ██║  ██║██████╔╝██║   ██║██║   ██║██╔██╗ ██║      ║
║      ██║  ██║██╔══██╗██║   ██║██║   ██║██║╚██╗██║      ║
║      ██████╔╝██║  ██║╚██████╔╝╚██████╔╝██║ ╚████║      ║
║      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝      ║
║                                                          ║
║         🐉  D R O G O N  B I N D  T O O L  🐉          ║
╚══════════════════════════════════════════════════════════╝{Colors.END}"""
    print(dragon_logo)
    
    # Decorative separator
    print(f"{Colors.DARK_RED}╔{'═' * 58}╗{Colors.END}")
    print(f"{Colors.DARK_RED}║{Colors.END} {Colors.GOLD}🐉 DEVELOPER :{Colors.END} {Colors.WHITE} @SKY_DROGON {Colors.END}{Colors.DARK_RED}                 ║{Colors.END}")
    print(f"{Colors.DARK_RED}║{Colors.END} {Colors.GOLD}🔥 CHANNEL  :{Colors.END} {Colors.WHITE} @DRAGON_AARMY_LEGEND_1 {Colors.END}{Colors.DARK_RED}         ║{Colors.END}")
    print(f"{Colors.DARK_RED}║{Colors.END} {Colors.GOLD}⚡ STATUS   :{Colors.END} {Colors.GREEN} PREMIUM & SECURE {Colors.END}{Colors.DARK_RED}          ║{Colors.END}")
    print(f"{Colors.DARK_RED}╚{'═' * 58}╝{Colors.END}")
    
    print(f"\n{Colors.ORANGE}◈{'═' * 58}◈{Colors.END}\n")
    
    if subtitle:
        print(f" {Colors.GOLD}▶ {Colors.WHITE}{Colors.BOLD}{subtitle}{Colors.END}")
        print(f"\n{Colors.ORANGE}◈{'═' * 58}◈{Colors.END}\n")

def input_prompt(msg):
    return input(f"{Colors.GOLD}» {Colors.WHITE}{msg} : {Colors.END}").strip()

def print_step(current, total, msg):
    print(f"\n {Colors.ORANGE}▶ {Colors.GOLD}[{current}/{total}]{Colors.END} {Colors.WHITE}{msg}{Colors.END}")

def print_success(msg):
    print(f" {Colors.GREEN}✓ {msg}{Colors.END}")

def print_error(msg):
    print(f" {Colors.RED}✗ {msg}{Colors.END}")

def print_info(msg):
    print(f" {Colors.CYAN}ℹ {msg}{Colors.END}")

def wait_for_enter():
    print(f"\n{Colors.ORANGE}◈{'═' * 58}◈{Colors.END}\n")
    input(f"{Colors.GOLD}» {Colors.WHITE}Press Enter to return to menu : {Colors.END}")
    print(Colors.END, end="")


def format_response(response_text, title="API Response"):
    try:
        parsed = json.loads(response_text)
        result_code = parsed.get("result")
        
        if result_code == 0:
            print_success(f"{title}: SUCCESS")
        elif result_code is not None:
            error_msg = parsed.get("error", "Unknown error")
            print_error(f"{title}: FAILED (Code: {result_code} | {error_msg})")
        else:
            print_info(f"{title}: Completed (No standard result code)")
            
    except Exception:
        if '"result": 0' in response_text.replace(" ", ""):
            print_success(f"{title}: SUCCESS")
        else:
            print_error(f"{title}: Unrecognized response format")


def convert_seconds(s):
    d, h = divmod(s, 86400)
    h, m = divmod(h, 3600)
    m, s = divmod(m, 60)
    return f"{d} Day {h} Hour {m} Min {s} Sec"


PLATFORM_MAP = {
    1: "Garena", 3: "Facebook", 4: "Guest", 5: "VK", 
    6: "Huawei", 7: "Apple", 8: "Google", 10: "GameCenter / Line", 
    11: "X (Twitter)", 13: "Apple ID", 28: "Line", 35: "TikTok"
}

def check_bind_info(access_token=None, show_raw=False):
    if not access_token:
        access_token = input_prompt("Enter Access Token")
    
    print_info("Fetching account bind information from Garena...\n")
    

    try:
        player_url = f"https://api-otrss.garena.com/support/callback/?access_token={access_token}"
        player_headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
        }

        p_res = requests.get(player_url, headers=player_headers, timeout=15, allow_redirects=True)
        
        parsed_url = urllib.parse.urlparse(p_res.url)
        query_params = urllib.parse.parse_qs(parsed_url.query)
        
        uid = query_params.get("account_id", ["Unknown"])[0]
        nickname = query_params.get("nickname", ["Unknown"])[0]
        region = query_params.get("region", ["Unknown"])[0]
        
        print(f"  {Colors.GREEN}{Colors.BOLD}≡ Player Information{Colors.END}")
        print(f"    {Colors.GOLD}● UID:{Colors.END}       {Colors.WHITE}{uid}{Colors.END}")
        print(f"    {Colors.YELLOW}● Nickname:{Colors.END}  {Colors.WHITE}{nickname}{Colors.END}")
        print(f"    {Colors.MAGENTA}● Region:{Colors.END}    {Colors.WHITE}{region}{Colors.END}\n")
        
    except Exception as e:
        print_error(f"Failed to fetch player details: {str(e)}\n")


    url = "https://100067.connect.garena.com/game/account_security/bind:get_bind_info"
    payload = {'app_id': "100067", 'access_token': access_token}
    headers = {
        'User-Agent': "GarenaMSDK/4.0.19P9(Redmi Note 5 ;Android 9;en;US;)",
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip"
    }
    
    try:
        response = requests.get(url, params=payload, headers=headers, timeout=15)
        
        print(f"  {Colors.GREEN}{Colors.BOLD}≡ Bind Information{Colors.END}")
        
        if response.status_code == 200:
            data = response.json()
            
            email = data.get("email", "")
            email_to_be = data.get("email_to_be", "")
            countdown = data.get("request_exec_countdown", 0)
            
            countdown_human = convert_seconds(countdown)
            result_code = data.get("result", -1)
            
            print(f"    {Colors.CYAN}● Current Email:{Colors.END}  {Colors.WHITE}{email if email else 'None'}{Colors.END}")
            print(f"    {Colors.YELLOW}● Pending Email:{Colors.END}  {Colors.WHITE}{email_to_be if email_to_be else 'None'}{Colors.END}")
            if email_to_be:
                print(f"    {Colors.MAGENTA}● Countdown:{Colors.END}      {Colors.WHITE}{countdown_human}{Colors.END}")
            if result_code == 0:
                print(f"    {Colors.GREEN}● Result:{Colors.END}         {Colors.GREEN}✓ SUCCESS{Colors.END}")
            else:
                print(f"    {Colors.RED}● Result:{Colors.END}         {Colors.RED}✗ FAILED (Code: {result_code}){Colors.END}")

            summary = ""
            if email == "" and email_to_be != "":
                summary = f"Pending email confirmation: {email_to_be} - Confirms in: {countdown_human}"
            elif email != "" and email_to_be == "":
                summary = f"Email confirmed: {email}"
            elif email == "" and email_to_be == "":
                summary = "No recovery email set"
                
            if summary:
                print(f"\n    {Colors.BLUE}● Summary:{Colors.END} {Colors.WHITE}{summary}{Colors.END}")

            if show_raw:
                print(f"\n    {Colors.DIM}Raw Response: {json.dumps(data)}{Colors.END}")
                
        else:
            print_error(f"API Error (Status {response.status_code}): {response.text[:100]}")
            
    except Exception as e:
        print_error(f"Failed to fetch info: {str(e)}")


def bind_email():
    draw_header("BIND EMAIL")
    
    access_token = input_prompt("Enter Access Token")
    print("")
    check_bind_info(access_token, show_raw=False)
    print("")
    email = input_prompt("Enter Email to bind")
    
    headers = {
        "User-Agent": "GarenaMSDK/4.0.30",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json"
    }

    print_step(1, 3, f"Sending OTP to {email}...")
    send_otp_url = "https://100067.connect.garena.com/game/account_security/bind:send_otp"
    send_otp_data = {
        "email": email,
        "locale": "en_PK",
        "region": "PK",
        "app_id": "100067",
        "access_token": access_token
    }
    resp_send = requests.post(send_otp_url, headers=headers, data=send_otp_data)
    format_response(resp_send.text, "Send OTP")

    otp = input_prompt("Enter OTP received in email")

    print_step(2, 3, "Verifying OTP securely...")
    verify_url = "https://100067.connect.garena.com/game/account_security/bind:verify_otp"
    verify_data = {
        "app_id": "100067",
        "access_token": access_token,
        "email": email,
        "code": otp,
        "otp": otp,
        "type": "1"
    }
    resp_verify = requests.post(verify_url, headers=headers, data=verify_data)
    format_response(resp_verify.text, "Verify OTP")

    verifier_token = ""
    try:
        verifier_token = resp_verify.json().get("verifier_token", "")
    except: pass

    if not verifier_token:
        print_error("Could not automatically extract verifier_token.")
        verifier_token = input_prompt("Please enter the verifier_token manually")
    else:
        print_success("Verifier Token extracted successfully!")

    security_code = input_prompt("Set 6-digits security code")

    print_step(3, 3, "Creating bind request...")
    bind_url = "https://100067.connect.garena.com/game/account_security/bind:create_bind_request"
    bind_data = {
        "email": email,
        "app_id": "100067",
        "access_token": access_token,
        "verifier_token": verifier_token,
        "secondary_password": security_code
    }
    resp_bind = requests.post(bind_url, headers=headers, data=bind_data)
    format_response(resp_bind.text, "Final Bind Request")

    wait_for_enter()


def change_bind_email():
    draw_header("CHANGE BIND EMAIL")
    
    print(f" {Colors.CYAN}CHOOSE CHANGE METHOD:{Colors.END}")
    print(f" {Colors.GOLD}▶ [{Colors.WHITE}1{Colors.GOLD}] {Colors.WHITE}CHANGE VIA OTP{Colors.END}")
    print(f" {Colors.GOLD}▶ [{Colors.WHITE}2{Colors.GOLD}] {Colors.WHITE}CHANGE VIA SECURITY CODE{Colors.END}")
    print(f" {Colors.GOLD}▶ {Colors.RED}[0] CANCEL & GO BACK{Colors.END}\n")
    
    choice = input_prompt("Select Method")
    if choice == "0":
        return
    if choice not in ["1", "2"]:
        print_error("Invalid option selected!")
        return wait_for_enter()

    access_token = input_prompt("Enter Access Token")
    print("")
    check_bind_info(access_token, show_raw=False)
    
    try:
        url_info = "https://100067.connect.garena.com/game/account_security/bind:get_bind_info"
        info_payload = {'app_id': "100067", 'access_token': access_token}
        info_headers = {'User-Agent': "GarenaMSDK/4.0.30"}
        r_info = requests.get(url_info, params=info_payload, headers=info_headers, timeout=10)
        old_email = r_info.json().get("email", "")
    except:
        old_email = ""
        
    if not old_email:
        print_error("No currently bound email found! You cannot use 'Change Bind' without an existing email.")
        return wait_for_enter()
    
    headers = {
        "User-Agent": "GarenaMSDK/4.0.30",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json"
    }
    
    identity_token = None
    total_steps = 5 if choice == "1" else 4
    current_step = 1

    if choice == "1":
        print_step(current_step, total_steps, f"Sending OTP to {old_email}...")
        url_send = "https://100067.connect.garena.com/game/account_security/bind:send_otp"
        data = {"email": old_email, "locale": "en_PK", "region": "PK", "app_id": "100067", "access_token": access_token}
        r = requests.post(url_send, headers=headers, data=data)
        format_response(r.text, "Send Old Email OTP")
        current_step += 1
            
        otp_old = input_prompt(f"Enter OTP from {old_email}")
            
        print_step(current_step, total_steps, "Verifying Old Email Identity...")
        url_verify_identity = "https://100067.connect.garena.com/game/account_security/bind:verify_identity"
        data = {"email": old_email, "app_id": "100067", "access_token": access_token, "otp": otp_old}
        r = requests.post(url_verify_identity, headers=headers, data=data)
        format_response(r.text, "Verify Identity")
        current_step += 1
        
        try: identity_token = r.json().get("identity_token")
        except: pass

    else:
        sec_code = input_prompt("Enter 6-digit Security Code")
        
        hashed_sec_code = hashlib.sha256(sec_code.encode('utf-8')).hexdigest()
        
        print_step(current_step, total_steps, "Verifying Identity via Security Code...")
        url_verify_identity = "https://100067.connect.garena.com/game/account_security/bind:verify_identity"
        data = {"email": old_email, "app_id": "100067", "access_token": access_token, "secondary_password": hashed_sec_code}
        r = requests.post(url_verify_identity, headers=headers, data=data)
        format_response(r.text, "Verify Identity")
        current_step += 1
        
        try: identity_token = r.json().get("identity_token")
        except: pass

    if identity_token:
        print_success("Identity Token Extracted!")
    else:
        print_error("No identity token received or verification failed!")
        return wait_for_enter()

    new_email = input_prompt("Enter New Email")

    print_step(current_step, total_steps, f"Sending OTP to {new_email}...")
    url_send = "https://100067.connect.garena.com/game/account_security/bind:send_otp"
    data = {"email": new_email, "locale": "en_PK", "region": "PK", "app_id": "100067", "access_token": access_token}
    r = requests.post(url_send, headers=headers, data=data)
    format_response(r.text, "Send New Email OTP")
    current_step += 1
    
    otp_new = input_prompt(f"Enter OTP from {new_email}")

    print_step(current_step, total_steps, "Verifying New Email OTP...")
    url_verify_otp = "https://100067.connect.garena.com/game/account_security/bind:verify_otp"
    data = {"email": new_email, "app_id": "100067", "access_token": access_token, "otp": otp_new}
    r = requests.post(url_verify_otp, headers=headers, data=data)
    format_response(r.text, "Verify OTP")
    current_step += 1

    verifier_token = None
    try:
        verifier_token = r.json().get("verifier_token")
        if verifier_token:
            print_success("Verifier Token Extracted!")
        else:
            print_error("No verifier token received!")
            return wait_for_enter()
    except:
        return wait_for_enter()

    print_step(current_step, total_steps, "Creating Rebind Request...")
    url_rebind = "https://100067.connect.garena.com/game/account_security/bind:create_rebind_request"
    data = {"identity_token": identity_token, "email": new_email, "app_id": "100067", "verifier_token": verifier_token, "access_token": access_token}
    r = requests.post(url_rebind, headers=headers, data=data)
    format_response(r.text, "Rebind Request")

    wait_for_enter()


def unbind_email():
    draw_header("UNBIND EMAIL")
    
    print(f" {Colors.CYAN}CHOOSE UNBIND METHOD:{Colors.END}")
    print(f" {Colors.GOLD}▶ [{Colors.WHITE}1{Colors.GOLD}] {Colors.WHITE}UNBIND VIA OTP{Colors.END}")
    print(f" {Colors.GOLD}▶ [{Colors.WHITE}2{Colors.GOLD}] {Colors.WHITE}UNBIND VIA SECURITY CODE{Colors.END}")
    print(f" {Colors.GOLD}▶ {Colors.RED}[0] CANCEL & GO BACK{Colors.END}\n")
    
    choice = input_prompt("Select Method")
    if choice == "0":
        return
    if choice not in ["1", "2"]:
        print_error("Invalid option selected!")
        return wait_for_enter()

    access_token = input_prompt("Enter Access Token")
    print("")
    check_bind_info(access_token, show_raw=False)
    

    try:
        url_info = "https://100067.connect.garena.com/game/account_security/bind:get_bind_info"
        info_payload = {'app_id': "100067", 'access_token': access_token}
        info_headers = {'User-Agent': "GarenaMSDK/4.0.30"}
        r_info = requests.get(url_info, params=info_payload, headers=info_headers, timeout=10)
        email = r_info.json().get("email", "")
    except:
        email = ""
        
    if not email:
        print_error("No currently bound email found! You cannot use 'Unbind' without an existing email.")
        return wait_for_enter()
    
    headers = {
        "User-Agent": "GarenaMSDK/4.0.30",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json"
    }

    identity_token = None

    if choice == "1":
        print_step(1, 3, f"Sending OTP to {email}...")
        send_otp_url = "https://100067.connect.garena.com/game/account_security/bind:send_otp"
        send_otp_data = {"email": email, "locale": "en_PK", "region": "PK", "app_id": "100067", "access_token": access_token}
        resp = requests.post(send_otp_url, headers=headers, data=send_otp_data)
        format_response(resp.text, "Send OTP")
        
        otp = input_prompt(f"Enter OTP from {email}")
        
        print_step(2, 3, "Verifying Identity...")
        verify_url = "https://100067.connect.garena.com/game/account_security/bind:verify_identity"
        verify_data = {"email": email, "app_id": "100067", "access_token": access_token, "otp": otp}
        resp = requests.post(verify_url, headers=headers, data=verify_data)
        format_response(resp.text, "Verify Identity")
        
        try: identity_token = resp.json().get("identity_token")
        except: pass
        step_final = 3

    else:
        sec_code = input_prompt("Enter 6-digit Security Code")
        
        hashed_sec_code = hashlib.sha256(sec_code.encode('utf-8')).hexdigest()
        
        print_step(1, 2, "Verifying Identity via Security Code...")
        verify_url = "https://100067.connect.garena.com/game/account_security/bind:verify_identity"
        verify_data = {"email": email, "app_id": "100067", "access_token": access_token, "secondary_password": hashed_sec_code}
        resp = requests.post(verify_url, headers=headers, data=verify_data)
        format_response(resp.text, "Verify Identity")
        
        try: identity_token = resp.json().get("identity_token")
        except: pass
        step_final = 2

    if identity_token:
        print_success("Identity Token Extracted!")
    else:
        print_error("Identity verification failed!")
        return wait_for_enter()

    total_steps = 3 if choice == "1" else 2
    print_step(step_final, total_steps, "Creating Unbind Request...")
    unbind_url = "https://100067.connect.garena.com/game/account_security/bind:create_unbind_request"
    unbind_data = {"app_id": "100067", "access_token": access_token, "identity_token": identity_token}
    resp = requests.post(unbind_url, headers=headers, data=unbind_data)
    format_response(resp.text, "Unbind Request")
    
    wait_for_enter()


def cancel_bind():
    draw_header("CANCEL BIND REQUEST")
    
    access_token = input_prompt("Enter Access Token")
    print("")
    check_bind_info(access_token, show_raw=False)
    
    print_step(1, 1, "Creating Cancel Request...")
    url = "https://100067.connect.garena.com/game/account_security/bind:cancel_request"
    headers = {
        "User-Agent": "GarenaMSDK/4.0.30",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json"
    }
    data = {"app_id": "100067", "access_token": access_token}
    response = requests.post(url, headers=headers, data=data)
    
    format_response(response.text, "Cancel Request")
    wait_for_enter()



def bind_info():
    draw_header("CHECK BIND INFO")
    access_token = input_prompt("Enter Access Token")
    print("")
    check_bind_info(access_token, show_raw=False)
    wait_for_enter()


def eat_to_access_token():
    draw_header("EAT TO ACCESS TOKEN")
    
    user_input = input_prompt("Enter EAT Token OR Full EAT URL")
    
    eat_token = None
    if "http" in user_input or "?" in user_input:
        parsed_url = urllib.parse.urlparse(user_input)
        query_params = urllib.parse.parse_qs(parsed_url.query)
        if 'eat' in query_params:
            eat_token = query_params['eat'][0]
    else:
        eat_token = user_input.strip()
        
    if not eat_token:
        print_error("Could not find an EAT token in your input.")
        return wait_for_enter()
        
    print_step(1, 1, "Contacting Server & Following Redirects...")
    
    api_url = f"https://api-otrss.garena.com/support/callback/?access_token={eat_token}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36"
    }
    
    try:
        response = requests.get(api_url, headers=headers, allow_redirects=True, timeout=15)
        parsed_final = urllib.parse.urlparse(response.url)
        final_params = urllib.parse.parse_qs(parsed_final.query)
        
        if 'access_token' in final_params:
            access_token = final_params['access_token'][0]
            account_id = final_params.get('account_id', ['Unknown'])[0]
            nickname = final_params.get('nickname', ['Unknown'])[0]
            region = final_params.get('region', ['Unknown'])[0]
            

            print(f"\n{Colors.GREEN}╔{'═' * 19} ═══ SUCCESS ═══ {'═' * 20}╗{Colors.END}")
            print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Nickname    :{Colors.END} {Colors.WHITE}{urllib.parse.unquote(nickname)}{Colors.END}")
            print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Account ID  :{Colors.END} {Colors.WHITE}{account_id}{Colors.END}")
            print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Region      :{Colors.END} {Colors.WHITE}{region}{Colors.END}")
            print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Access Token:{Colors.END}")
            print(f"{Colors.GREEN}║{Colors.END}  {Colors.YELLOW}{access_token}{Colors.END}")
            print(f"{Colors.GREEN}╚{'═' * 58}╝{Colors.END}")
            
        else:
            print_error("Access token not found. The token might be expired or invalid.")
            
    except Exception as e:
        print_error(f"Failed to generate access token: {str(e)}")
        
    wait_for_enter()


def revoke_access_token():
    draw_header("REVOKE ACCESS TOKEN")
    
    access_token = input_prompt("Enter Access Token to Revoke")
    if not access_token:
        print_error("Token cannot be empty.")
        return wait_for_enter()
        
    print_step(1, 2, "Checking Token Status & Fetching Info...")
    
    api_url = f"https://api-otrss.garena.com/support/callback/?access_token={access_token}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
    }
    
    nickname = "Unknown"
    account_id = "Unknown"
    region = "Unknown"
    is_valid = False
    
    try:
        res = requests.get(api_url, headers=headers, allow_redirects=True, timeout=15)
        parsed = urllib.parse.urlparse(res.url)
        params = urllib.parse.parse_qs(parsed.query)
        
        if 'access_token' in params:
            is_valid = True
            nickname = urllib.parse.unquote(params.get('nickname', ['Unknown'])[0])
            account_id = params.get('account_id', ['Unknown'])[0]
            region = params.get('region', ['Unknown'])[0]
    except Exception:
        pass
        
    if not is_valid:
        print_error("Token is already invalid, expired, or revoked!")
        return wait_for_enter()
        
    print_success(f"Token is Valid!")
    
    print_step(2, 2, "Revoking Token Access (Logging Out)...")
    
    refresh_token = "1380dcb63ab3a077dc05bdf0b25ba4497c403a5b4eae96d7203010eafa6c83a8"
    logout_url = f"https://100067.connect.garena.com/oauth/logout?access_token={access_token}&refresh_token={refresh_token}"
    
    try:
        logout_res = requests.get(logout_url, headers=headers, timeout=15)
        
        if logout_res.status_code == 200 and "error" not in logout_res.text:

            print(f"\n{Colors.GREEN}╔{'═' * 19} ═══ REVOKED ═══ {'═' * 20}╗{Colors.END}")
            print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Nickname    :{Colors.END} {Colors.WHITE}{nickname}{Colors.END}")
            print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Account ID  :{Colors.END} {Colors.WHITE}{account_id}{Colors.END}")
            print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Region      :{Colors.END} {Colors.WHITE}{region}{Colors.END}")
            print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Status      :{Colors.END} {Colors.GREEN}Successfully Logged Out & Revoked{Colors.END}")
            print(f"{Colors.GREEN}╚{'═' * 58}╝{Colors.END}\n")
        else:
            print_error("Failed to revoke token! Server responded with an error.")
            
    except Exception as e:
        print_error(f"Error while revoking token: {str(e)}")
        
    wait_for_enter()

def access_to_jwt():
    draw_header("ACCESS TOKEN TO JWT")

    token = input_prompt("Enter Access Token")
    if not token:
        print_error("Empty Input! Token cannot be blank.")
        return wait_for_enter()

    print_step(1, 1, "Connecting to JWT API Server...")

    url = f"https://jwt-system-ff.vercel.app/access_to_jwt?access_token={token}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    try:
        response = requests.get(url, headers=headers, timeout=15)

        if response.status_code == 200:
            data = response.json()

            if data.get("success"):
                print("\n" + f"{Colors.GREEN}╔{'═'*58}╗{Colors.END}")
                print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 JWT GENERATED{Colors.END}")
                print(f"{Colors.GREEN}╠{'═'*58}╣{Colors.END}")

                print(f"{Colors.GREEN}║{Colors.END} UID        : {Colors.YELLOW}{data.get('uid')}{Colors.END}")
                print(f"{Colors.GREEN}║{Colors.END} Nickname   : {Colors.YELLOW}{data.get('nickname')}{Colors.END}")
                print(f"{Colors.GREEN}║{Colors.END} Region     : {Colors.YELLOW}{data.get('lock_region')}{Colors.END}")
                print(f"{Colors.GREEN}║{Colors.END} Platform   : {Colors.YELLOW}{data.get('platform_name')}{Colors.END}")
                print(f"{Colors.GREEN}║{Colors.END} Open ID    : {Colors.YELLOW}{data.get('open_id')}{Colors.END}")

                print(f"\n{Colors.GREEN}║{Colors.END} {Colors.GOLD}JWT TOKEN:{Colors.END}")
                print(f"{Colors.YELLOW}{data.get('jwt_token')}{Colors.END}")

                print(f"\n{Colors.GREEN}║{Colors.END} Channel    : {Colors.YELLOW}{data['credits']['chhanal']}{Colors.END}")
                print(f"{Colors.GREEN}║{Colors.END} Telegram   : {Colors.YELLOW}{data['credits']['telegram']}{Colors.END}")
                print(f"{Colors.GREEN}╚{'═'*58}╝{Colors.END}")

            else:
                print_error("API returned success=False")
                print(data)

        else:
            print_error(f"Server Error! HTTP Status Code: {response.status_code}")

    except Exception as e:
        print_error(f"Connection Failed: {e}")

    wait_for_enter()

def ban_account():
    draw_header("BAN ACCOUNT (ACCESS TOKEN TO BAN)")
    
    token = input_prompt("Enter Access Token")
    if not token:
        print_error("Empty Input! Token cannot be blank.")
        return wait_for_enter()
        
    print_step(1, 1, "Sending Ban Request to API Server...")
    
    url = f"https://toji-api-jwt.vercel.app/ban?token={token}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=20)
        print("\n" + f"{Colors.GREEN}╔{'═' * 16} ═══ API RESPONSE ═══ {'═' * 17}╗{Colors.END}")
        
        if response.status_code == 200:
            raw_text = response.text.strip()
            try:
                parsed_json = json.loads(raw_text)
                print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Raw JSON Response:{Colors.END}")
                print(f"{Colors.GREEN}║{Colors.END}  {Colors.WHITE}{json.dumps(parsed_json, indent=4)}{Colors.END}")
            except Exception:
                print(f"{Colors.GREEN}║{Colors.END}  {Colors.WHITE}{raw_text}{Colors.END}")
        else:
            print_error(f"Server Alert! HTTP Status Code: {response.status_code}")
            print(f" {Colors.DIM}Response: {response.text}{Colors.END}")
            
        print(f"{Colors.GREEN}╚{'═' * 58}╝{Colors.END}")
    except Exception as e:
        print_error(f"Connection Failed: {str(e)}")
        
    wait_for_enter()


AeSkEy = b'Yg&tc%DEuh6%Zc^8'
AeSiV  = b'6oyZDr22E3ychjM%'

def enc(d): return AES.new(AeSkEy, AES.MODE_CBC, AeSiV).encrypt(pad(d, 16))
def dec(d): return unpad(AES.new(AeSkEy, AES.MODE_CBC, AeSiV).decrypt(d), 16)

def build_majorlogin(tok, open_id, p_type):
    m = mLpB.MajorLogin()
    m.event_time = str(datetime.now())[:-7]
    m.game_name = "free fire"
    m.platform_id = p_type
    m.client_version = "1.120.1"
    m.system_software = "Android OS 9 / API-28"
    m.system_hardware = "Handheld"
    m.telecom_operator = "Verizon"
    m.network_type = "WIFI"
    m.screen_width = 1920
    m.screen_height = 1080
    m.screen_dpi = "280"
    m.processor_details = "ARM64 FP ASIMD AES VMH | 2865 | 4"
    m.memory = 3003
    m.gpu_renderer = "Adreno (TM) 640"
    m.gpu_version = "OpenGL ES 3.1 v1.46"
    m.unique_device_id = "Google|34a7dcdf-a7d5-4cb6-8d7e-3b0e448a0c57"
    m.client_ip = "223.191.51.89"
    m.language = "en"
    m.open_id = open_id
    m.open_id_type = str(p_type)
    m.device_type = "Handheld"
    m.access_token = tok
    m.platform_sdk_id = 1
    m.client_using_version = "7428b253defc164018c604a1ebbfebdf"
    m.login_by = 3
    m.channel_type = 3
    m.cpu_type = 2
    m.cpu_architecture = "64"
    m.client_version_code = "2019118695"
    m.login_open_id_type = p_type
    m.origin_platform_type = str(p_type)
    m.primary_platform_type = str(p_type)
    return enc(m.SerializeToString())

def read_varint(data, offset):
    res = 0; shift = 0
    while True:
        if offset >= len(data): break
        b = data[offset]; offset += 1
        res |= (b & 0x7f) << shift
        if not (b & 0x80): break
        shift += 7
    return res, offset

def parse_record(data):
    rec = {}; offset = 0
    while offset < len(data):
        tag, offset = read_varint(data, offset)
        wt, f = tag & 7, tag >> 3
        if wt == 0:
            val, offset = read_varint(data, offset)
            if f == 1: rec['ts'] = val
            elif f == 2: rec['ram'] = val
        elif wt == 2:
            length, offset = read_varint(data, offset)
            val = data[offset:offset+length]; offset += length
            if f == 3: rec['dev'] = val.decode(errors='ignore')
            elif f == 4: rec['arch'] = val.decode(errors='ignore')
        else: break
    return rec

def parse_history_protobuf(data):
    records = []; offset = 0
    while offset < len(data):
        tag, offset = read_varint(data, offset)
        wt, f = tag & 7, tag >> 3
        if wt == 0: val, offset = read_varint(data, offset)
        elif wt == 2:
            length, offset = read_varint(data, offset)
            val = data[offset:offset+length]; offset += length
            if f == 1: records.append(parse_record(val))
        else: break
    return records

def login_history():
    draw_header("GET LOGIN HISTORY")
    
    token = input_prompt("Enter Access Token OR Game JWT Token")
    if not token:
        print_error("Empty Input! Token cannot be blank.")
        return wait_for_enter()
        
    jwt_token = None
    
    if token.startswith("ey") and "." in token:
        jwt_token = token
        print_success("Detected valid JWT Token.")
    else:
        print_step(1, 2, "Resolving Open ID from Access Token...")
        oId = None
        
        try:
            r = requests.get(f"https://100067.connect.garena.com/oauth/token/inspect?token={token}", headers={"User-Agent": "Mozilla/5.0"}, timeout=5).json()
            oId = r.get("open_id")
        except: pass

        if not oId:
            try:
                uid_headers = {"access-token": token, "user-agent": "Mozilla/5.0"}
                uid_res = requests.get("https://prod-api.reward.ff.garena.com/redemption/api/auth/inspect_token/", headers=uid_headers, verify=False, timeout=5).json()
                uid = uid_res.get("uid")
                if uid:
                    openid_res = requests.post("https://topup.pk/api/auth/player_id_login", json={"app_id": 100067, "login_id": str(uid)}, verify=False, timeout=5).json()
                    oId = openid_res.get("open_id")
            except: pass

        if not oId:
            print_error("Failed to extract Open ID. Token is likely invalid or expired.")
            return wait_for_enter()
            
        print_success(f"Open ID Extracted: {oId}")
        print_step(2, 2, "Bypassing MajorLogin via Protobufs...")
        
        platforms = [8, 3, 4, 6] 
        for p_type in platforms:
            pl = build_majorlogin(token, oId, p_type)
            try:
                mLhDr  = {
                    "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 11; SM-S908E Build/TP1A.220624.014)",
                    "Connection": "Keep-Alive", "Accept-Encoding": "gzip",
                    "Content-Type": "application/octet-stream", "Expect": "100-continue",
                    "X-GA": "v1 1", "X-Unity-Version": "2018.4.11f1", "ReleaseVersion": "OB52"
                }
                x = requests.post("https://loginbp.ggpolarbear.com/MajorLogin", headers=mLhDr, data=pl, timeout=10, verify=False)
                if x.status_code == 200:
                    res = mLrPb.MajorLoginRes()
                    try: res.ParseFromString(dec(x.content))
                    except: res.ParseFromString(x.content)
                    if res.token:
                        jwt_token = res.token
                        print_success(f"JWT Token Generated Successfully via Platform ID {p_type}!")
                        break
            except: continue
            
        if not jwt_token:
            print_error("MajorLogin failed across all platforms. Token might be blocked.")
            return wait_for_enter()

    try:
        payload_b64 = jwt_token.split('.')[1]
        payload_b64 += "=" * ((4 - len(payload_b64) % 4) % 4)
        decoded = json.loads(base64.urlsafe_b64decode(payload_b64).decode('utf-8'))
        
        name = urllib.parse.unquote(decoded.get("nickname", "Unknown"))
        uid = decoded.get("account_id", "Unknown")
        region = decoded.get("lock_region", "Unknown")
        p_id = decoded.get("external_type", 0)
        platform = PLATFORM_MAP.get(p_id, f"Unknown ({p_id})")
        
        print(f"\n{Colors.GREEN}╔{'═' * 17} ═══ PLAYER INFO ═══ {'═' * 18}╗{Colors.END}")
        print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Account Name:{Colors.END} {Colors.WHITE}{name}{Colors.END}")
        print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Account ID  :{Colors.END} {Colors.WHITE}{uid}{Colors.END}")
        print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Platform    :{Colors.END} {Colors.WHITE}{platform}{Colors.END}")
        print(f"{Colors.GREEN}║{Colors.END} {Colors.GOLD}🐉 Region      :{Colors.END} {Colors.WHITE}{region}{Colors.END}")
        print(f"{Colors.GREEN}╚{'═' * 58}╝{Colors.END}")
    except:
        pass

    print("")
    print_info("Fetching Login History Records...")
    print("")
    hH = {
        "Expect": "100-continue", "Authorization": f"Bearer {jwt_token}",
        "X-Unity-Version": "2018.4.11f1", "X-GA": "v1 1", "ReleaseVersion": "OB52",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        "Host": "client.ind.freefiremobile.com", "Connection": "close"
    }
    
    try:
        r = requests.post("https://client.ind.freefiremobile.com/GetLoginHistory", headers=hH, data=enc(b""), timeout=15, verify=False)
        if r.status_code != 200:
            print_error(f"History Request Failed: HTTP {r.status_code}")
            return wait_for_enter()
            
        try: d = dec(r.content)
        except: d = r.content
        
        records = parse_history_protobuf(d)
        
        print(f"\n{Colors.ORANGE}◈{'═' * 16} ═══ LOGIN HISTORY ═══ {'═' * 17}◈{Colors.END}\n")
        
        if not records:
            print(f" {Colors.GOLD}🐉 No login history records found for this account.{Colors.END}")
        else:
            for i, rec in enumerate(records, 1):
                ts_raw = rec.get('ts', 0)
                try: date_str = datetime.fromtimestamp(ts_raw).strftime('%Y-%m-%d %H:%M:%S')
                except: date_str = "Invalid Format"

                dev = rec.get('dev', 'Unknown Device')
                arch = rec.get('arch', 'Unknown Architecture')
                ram = rec.get('ram', 0)

                print(f" {Colors.GREEN}▶ Record #{i}{Colors.END}")
                print(f"   {Colors.GOLD}● Timestamp/ID :{Colors.END} {Colors.WHITE}{ts_raw}{Colors.END}")
                print(f"   {Colors.GOLD}● Last Login   :{Colors.END} {Colors.WHITE}{date_str}{Colors.END}")
                print(f"   {Colors.GOLD}● Device       :{Colors.END} {Colors.WHITE}{dev}{Colors.END}")
                print(f"   {Colors.GOLD}● Architecture :{Colors.END} {Colors.WHITE}{arch}{Colors.END}")
                print(f"   {Colors.GOLD}● Memory (RAM) :{Colors.END} {Colors.WHITE}{ram} MB{Colors.END}\n")
                
        print(f"{Colors.ORANGE}◈{'═' * 58}◈{Colors.END}")
        
    except Exception as e:
        print_error(f"Connection or Decoding Error: {str(e)}")

    wait_for_enter()


def check_bound_accounts():
    draw_header("PLATFORM BIND INFO")
    
    access_token = input_prompt("Enter Access Token")
    if not access_token:
        print_error("Token cannot be blank.")
        return wait_for_enter()
        
    print("")
    print_info("Fetching platform bind data from Garena Server...")
    print("")
    
    url = "https://100067.connect.garena.com/bind/app/platform/info/get"
    params = {"access_token": access_token}
    headers = {
        "User-Agent": "GarenaMSDK/4.0.19P9(Redmi Note 5 ;Android 9;en;US;)",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip"
    }
    
    try:
        response = requests.get(url, params=params, headers=headers, timeout=10)
        
        if response.status_code != 200:
            print_error(f"Failed to fetch data (HTTP {response.status_code})")
            return wait_for_enter()
            
        d = response.json()
        
        bounded_accounts = d.get("bounded_accounts", [])
        available_platforms = d.get("available_platforms", [])
                
        print(f"{Colors.GOLD}◈{'═' * 16} ═══ PLATFORM BINDS ═══ {'═' * 16}◈{Colors.END}\n")
        
        print(f" {Colors.GREEN}✓ BOUND ACCOUNTS:{Colors.END}")
        if not bounded_accounts:
            print(f"   {Colors.YELLOW}● No third-party platforms are currently bound.{Colors.END}")
        else:
            for p_id in bounded_accounts:
                p_name = PLATFORM_MAP.get(p_id, f"Unknown ({p_id})")
                print(f"   {Colors.GOLD}●{Colors.END} {Colors.WHITE}{p_name}{Colors.END}")
                
        print("")
        
        print(f" {Colors.CYAN}ℹ AVAILABLE PLATFORMS:{Colors.END}")
        if not available_platforms:
            print(f"   {Colors.DIM}● None{Colors.END}")
        else:
            for p_id in available_platforms:
                p_name = PLATFORM_MAP.get(p_id, f"Unknown ({p_id})")
                print(f"   {Colors.DIM}● {p_name}{Colors.END}")
                
        print(f"\n{Colors.GOLD}◈{'═' * 58}◈{Colors.END}")
        
    except Exception as e:
        print_error(f"Error fetching platform info: {str(e)}")
        print_error(f"Raw response might be different: {response.text}")
        
    wait_for_enter()


def owner_details():
    draw_header("OWNER DETAILS")
    
    print(f"\n{Colors.GOLD}╔{'═' * 16} ═══ DEVELOPER INFO ═══ {'═' * 16}╗{Colors.END}\n")
    
    print(f"{Colors.GOLD}║{Colors.END} {Colors.GOLD}🐉 Developer Name :{Colors.END} {Colors.WHITE}SKY DROGON{Colors.END}")
    print(f"{Colors.GOLD}║{Colors.END} {Colors.GOLD}🐉 Telegram       :{Colors.END} {Colors.WHITE}⊛ @SKY_DROGON{Colors.END}")
    print(f"{Colors.GOLD}║{Colors.END} {Colors.GOLD}🐉 Channel / Group:{Colors.END} {Colors.WHITE}https://t.me/DRAGON_AARMY_LEGEND_1{Colors.END}")
    print(f"{Colors.GOLD}║{Colors.END} {Colors.GOLD}🐉 Tool Version   :{Colors.END} {Colors.GREEN}v3.0 (Premium Dragon Edition){Colors.END}")
    
    print(f"\n{Colors.GOLD}╠{'═' * 18} ═══ SPECIAL NOTE ═══ {'═' * 16}╣{Colors.END}\n")
    
    print(f"{Colors.GOLD}║{Colors.END} {Colors.YELLOW}🔥 Thank you for using Dragon Bind Tool!{Colors.END}")
    print(f"{Colors.GOLD}║{Colors.END} {Colors.WHITE}🐉 This tool was created to provide a fast, secure,{Colors.END}")
    print(f"{Colors.GOLD}║{Colors.END} {Colors.WHITE}🐉 and reliable way to manage Garena Bind Accounts.{Colors.END}")
    print(f"{Colors.GOLD}║{Colors.END} {Colors.WHITE}🐉 Please report any bugs directly on Telegram.{Colors.END}")
    
    print(f"\n{Colors.GOLD}╚{'═' * 58}╝{Colors.END}")
    
    wait_for_enter()


def show_menu():
    draw_header()
    print(f" {Colors.CYAN}🐉 DRAGON MENU OPTIONS:{Colors.END}")
    
    options = [
        ("1", "CHECK BIND INFO"),
        ("2", "BIND EMAIL"),
        ("3", "UNBIND EMAIL"),
        ("4", "CHANGE BIND EMAIL"),
        ("5", "CANCEL BIND REQUEST"),
        ("6", "EAT TO ACCESS TOKEN"),
        ("7", "REVOKE ACCESS TOKEN"),
        ("8", "GET LOGIN HISTORY"),
        ("9", "CHECK BOUND ACCOUNTS"),
        ("10", "ACCESS TOKEN TO JWT"),
        ("11", "OWNER DETAILS"),
        ("12", "ACCESS TOKEN TO BAN")
    ]
    
    for num, text in options:
        print(f" {Colors.GOLD}▶ [{Colors.WHITE}{num}{Colors.GOLD}] {Colors.WHITE}{text}{Colors.END}")
    
    print(f" {Colors.GOLD}▶ {Colors.RED}[0] EXIT{Colors.END}")
    
    print(f"\n{Colors.ORANGE}◈{'═' * 58}◈{Colors.END}\n")

def main():
    while True:
        show_menu()
        choice = input_prompt("Select Option")
        
        if choice == "1":
            bind_info()
        elif choice == "2":
            bind_email()
        elif choice == "3":
            unbind_email()
        elif choice == "4":
            change_bind_email()
        elif choice == "5":
            cancel_bind()
        elif choice == "6":
            eat_to_access_token()
        elif choice == "7":
            revoke_access_token()
        elif choice == "8":
            login_history()
        elif choice == "9":
            check_bound_accounts()
        elif choice == "10":
            access_to_jwt()
        elif choice == "11":
            owner_details()
        elif choice == "12":
            ban_account()
        elif choice == "0":
            clear_screen()
            print(f"\n {Colors.GOLD}🐉 {Colors.GREEN}Safely Exited. Bye! 👋{Colors.END}\n")
            sys.exit(0)
        else:
            print(f"\n {Colors.RED}✗ Invalid option! Please try again.{Colors.END}")
            time.sleep(1.5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n {Colors.GOLD}🐉 {Colors.GREEN}Safely Exited. Bye! 👋{Colors.END}\n")
        sys.exit(0)
    except Exception as e:
        print(f"\n {Colors.RED}✗ Error: {str(e)}{Colors.END}")
        input(f"\n {Colors.GOLD}» {Colors.WHITE}Press Enter to exit : {Colors.END}")